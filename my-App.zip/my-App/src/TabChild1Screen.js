import React, { Component } from 'react';
import { Text, FlatList, Animated, TouchableOpacity, View } from 'react-native';
import { withCollapsibleForTabChild } from 'react-navigation-collapsible';

const AnimatedFlatList = Animated.createAnimatedComponent(FlatList);

const GridBox = ({ number }) => {
  return (
    <View style={{
      width: 100,
      height: 100,
      justifyContent: "center",
      alignItems: "center",
      borderColor: 'grey',
      borderRadius: 5,
      borderWidth: 1,
      margin: 5
    }}>
      <Text>{number}</Text>
    </View>
  )
}

class TabChild1Screen extends Component {
  static navigationOptions = {
    title: 'Child 1'
  };

  constructor(props) {
    super(props);

    const data = [];
    for (let i = 0; i < 3; i++) {
      data.push(i);
    }

    this.state = {
      data: data,
    }
  }

  // renderItem = ({ item }) => (
  //   <TouchableOpacity
  //     onPress={() => {
  //       this.props.navigation.navigate('DetailScreen');
  //     }}
  //     style={{ width: '100%', height: 50, borderBottomColor: '#0002', borderBottomWidth: 0.5, paddingHorizontal: 20, justifyContent: 'center' }}>
  //     <Text style={{ fontSize: 22 }}>{item}</Text>
  //   </TouchableOpacity>
  // )

  renderItem = ({ item }) => (
    <View style={{
      display: "flex",
      flexDirection: 'column'
    }}>
      <View style={{
        display: "flex",
        flexDirection: 'row',
        justifyContent: 'center'
      }}>
        <GridBox number={1} />
        <GridBox number={2} />
        <GridBox number={3} />
      </View>
      <View style={{
        display: "flex",
        flexDirection: 'row',
        justifyContent: 'center'
      }}>
        <GridBox number={4} />
        <GridBox number={5} />
        <GridBox number={6} />
      </View>
      <View style={{
        display: "flex",
        flexDirection: 'row',
        justifyContent: 'center'
      }}>
        <GridBox number={7} />
        <GridBox number={8} />
        <GridBox number={9} />
      </View>
      <View style={{
        display: "flex",
        flexDirection: 'row',
        justifyContent: 'center'
      }}>
        <GridBox number={10} />
        <GridBox number={11} />
        <GridBox number={12} />
      </View>
    </View>
  )

  render() {
    const { animatedY, onScroll } = this.props.collapsible;

    return (
      <AnimatedFlatList
        style={{ flex: 1 }}
        data={this.state.data}
        renderItem={this.renderItem}
        keyExtractor={(item, index) => String(index)}

        onScroll={onScroll}
        _mustAddThis={animatedY}
      />
    )
  }
}

export default withCollapsibleForTabChild(TabChild1Screen);